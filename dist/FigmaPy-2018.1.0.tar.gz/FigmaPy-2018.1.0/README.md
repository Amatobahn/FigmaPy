![alt text](http://www.iamgregamato.com/img/fp_logo.svg)

An unofficial Python3+ wrapper for Figma API

### Install (Using Distributed Wheel from GitHub)
```bash
pip install FigmaPy-2018.1.0-py3-none-any.whl
```
API Documentation : https://www.figma.com/developers/docs
